
package TestUsuario;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author balbi
 */
public class Metodos {
    private static WebDriver driver = null; 
    public String texto;
    public String asercion;
    public int cuenta=0;
    FileWriter escritura;
    FileReader lector;
    BufferedReader contenido;
    String varusuario;
    String varclave;
    

    public void leerarchivo(String archivo) throws IOException{
        lector = new FileReader(archivo); 
        contenido =  new BufferedReader(lector);     
    }
    
    public void escribirarchivo(String escarchivo) throws IOException{
    File archivo = new File(escarchivo); 
    archivo.delete();
    escritura = new FileWriter(archivo,true);  
    }
    
    public void recorrerarchivo() throws IOException, InterruptedException{
     //////////   Bucle que lee hasta el final del archivo
    while((texto=contenido.readLine())!=null){  
        varusuario=datoarray(0);
        varclave=datoarray(1);
        cuenta++; 
        ejecutaselenium();
        }
    }
    
    
    public String datoarray(int i){
        String []Datos = texto.split(",");
//        System.out.println("El dato es:" +Datos[i]);
        return Datos[i];
    }
    
    public void cargardriver(String nombredriver){
    driver = new ChromeDriver();   
    System.setProperty("webdriver.chrome.driver",nombredriver);
  
    }
    
       public void llamarpagina(String nombreWeb){ 
               driver.get(nombreWeb); 
                // | Redimensionar la pantalla a  1382x744 píxeles 
       //         driver.manage().window().setSize(new Dimension(1382, 744));
                // | Maximizar la pantalla
                driver.manage().window().maximize();
                // | Full Screen como en YouTube
      //          driver.manage().window().fullscreen();
       }
       
       
       public void ejecutaselenium() throws IOException, InterruptedException{
              driver.findElement(By.id("usuario")).sendKeys(varusuario);
              driver.findElement(By.id("clave")).sendKeys(varclave);
            Thread.sleep(2000);
              driver.findElement(By.id("Ingresar")).click();
              asercion = driver.getPageSource();
            leeasercion(asercion);
           Thread.sleep(2000);
            driver.findElement(By.id("Volver")).click();
 
    }  
       
    public void leeasercion(String asercion) throws IOException{
        //cartelito(asercion);
        if (asercion.indexOf("Ingreso Incorrecto") >= 0){
               escritura.write(varusuario+varclave+"\r\n");    
        }else{
            escritura.write("Error en línea: " + cuenta + "-" + varusuario+varclave+"\r\n");     
        }  
    }
       
    public void cartelito(String mensaje){
        JOptionPane.showMessageDialog(null, mensaje);
        
    }
    
      public void cerrardriver(){
            driver.close();

        }
      public void cerrararchivo() throws IOException{
             escritura.close();  
      }
      
    
}
