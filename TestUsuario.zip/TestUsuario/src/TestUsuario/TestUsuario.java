package TestUsuario;

import java.io.IOException;

public class TestUsuario {
   
    public static void main(String[] args) throws IOException, InterruptedException  {
            Ventana VV = new Ventana();
            VV.setVisible(true);
            
    }
}
